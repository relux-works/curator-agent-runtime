from pathlib import Path
import json,subprocess,sys
cfg=json.loads(Path('task-board.config.json').read_text()); commands=cfg['spawn']['worktree_isolation']['validation']['commands']; results=[]
for i,cmd in enumerate(commands,1):
 p=Path(f'.temp/TASK-260908-q8pkiz/gate-{i:02d}.log')
 with p.open('w') as f: r=subprocess.run(cmd,shell=True,executable='/bin/zsh',stdout=f,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'exit_code':r.returncode,'log':str(p)})
 print(f'gate {i}: exit {r.returncode}')
Path('.temp/TASK-260908-q8pkiz/gates.json').write_text(json.dumps(results,indent=2)+'\n'); sys.exit(any(r['exit_code'] for r in results))
