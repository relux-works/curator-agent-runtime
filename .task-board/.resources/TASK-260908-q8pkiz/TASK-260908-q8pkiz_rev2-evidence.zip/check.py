from pathlib import Path
import subprocess,json,urllib.parse,sys
root=Path.cwd()
old="bdbeeea1474b0c37160338a86d7fbe287e4ee6ee"
def git(*args): return subprocess.check_output(["git",*args])
prior=set(git("ls-tree","-r","--name-only",old).decode().splitlines())
live=set(git("ls-files","--cached","--others","--exclude-standard").decode().splitlines())
def scoped(s): return {p for p in s if not p.startswith((".task-board/",".temp/"))}
prior,live=scoped(prior),scoped(live)
assert prior==live,(prior-live,live-prior)
changed=[p for p in sorted(prior) if git("show",old+":"+p)!=Path(p).read_bytes()]
assert changed==["README.md"],changed
before=git("show",old+":README.md").decode().splitlines()
after=Path("README.md").read_text().splitlines()
assert len(before)==len(after)
assert [i+1 for i,(a,b) in enumerate(zip(before,after)) if a!=b]==[38]
assert "ещё проходит" not in after[37] and "checkpoint" not in after[37]
assert "TASK-260908-q8pkiz" in after[37] and "review" in after[37]
def parse(path): return json.loads(subprocess.check_output(["pandoc","-f","gfm","-t","json",str(path)]))
def nodes(v):
 if isinstance(v,dict):
  yield v
  for x in v.values(): yield from nodes(x)
 elif isinstance(v,list):
  for x in v: yield from nodes(x)
links=[n["c"][-1][0] for n in nodes(parse("README.md")) if n.get("t") in ("Link","Image")]
local=[]
for target in links:
 u=urllib.parse.urlsplit(target)
 if u.scheme or target.startswith("//"): continue
 p=Path(urllib.parse.unquote(u.path)) if u.path else Path("README.md")
 assert p.exists(),target
 if u.fragment:
  ids={n["c"][1][0] for n in nodes(parse(p)) if n.get("t")=="Header"}
  assert urllib.parse.unquote(u.fragment) in ids,target
 local.append(target)
print(json.dumps({"prior_candidate":old,"files_compared":len(prior),"unchanged_files":len(prior)-1,"changed_paths":changed,"changed_lines":[38],"README_local_links_checked":len(local),"runtime_probes":0},indent=2))
