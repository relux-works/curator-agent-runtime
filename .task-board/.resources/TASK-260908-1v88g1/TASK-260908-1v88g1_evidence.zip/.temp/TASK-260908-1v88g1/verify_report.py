from pathlib import Path
import json,re,subprocess,xml.etree.ElementTree as ET
root=Path('.temp/TASK-260908-1v88g1')
refs=json.loads((root/'source-anchors.json').read_text())
for rid,repo,file,line,sym in refs:
 p=root/repo/file
 assert p.is_file(),str(p)
 lines=p.read_text().splitlines();assert 1<=line<=len(lines),(rid,line,len(lines))
for repo,expected in [('codex','8e694e955ae02ca737230a5468c55d5847074072'),('pi-mono','b2602be77cb7b0de45dd616407fd210daa48aa75')]:
 got=subprocess.check_output(['git','-C',str(root/repo),'rev-parse','HEAD'],text=True).strip();assert got==expected
 assert subprocess.check_output(['git','-C',str(root/repo),'status','--porcelain'],text=True)==''
report=Path('.research/260908_codex-pi.md').read_text()
assert 'SOURCE_TABLE' not in report
for name in ['kernel','recovery']:
 p=Path('diagrams/research/codex-pi')/(name+'.svg');ET.parse(p)
 assert 'Syntax Error' not in p.read_text()
for match in re.findall(r'\]\((../diagrams/[^)]+)\)',report):assert (Path('.research')/match).is_file(),match
print(f'PASS: {len(refs)}/{len(refs)} source paths and line anchors resolve; 2/2 SHA pins match; 2/2 source snapshots clean; 2/2 SVG parse; 2/2 report artifact links resolve.')
print('Bound: file/line existence and pinned identity, not semantic proof, renderer visual quality, external link availability, or executed upstream tests.')
