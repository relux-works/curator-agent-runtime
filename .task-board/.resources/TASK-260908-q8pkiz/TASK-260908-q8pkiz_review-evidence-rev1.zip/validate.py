from pathlib import Path
import re,json,hashlib,subprocess,sys,unicodedata,urllib.parse,xml.etree.ElementTree as ET
root=Path.cwd(); scratch=root/'.temp/TASK-260908-q8pkiz-review'
paths=[Path(x) for x in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines() if not x.startswith(('.task-board/','.temp/'))]
errors=[]; stats={}; inventory=[]
def require(ok,msg):
 if not ok: errors.append(msg)
def no_duplicates(pairs):
 d={}
 for k,v in pairs:
  if k in d: raise ValueError('duplicate key '+k)
  d[k]=v
 return d
def parse_json(s): return json.loads(s,object_pairs_hook=no_duplicates,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def strip_fences(s): return re.sub(r'^([`~]{3,})[^\n]*\n.*?^\1\s*$', '',s,flags=re.M|re.S)
def anchors(s):
 ids=set(re.findall(r'<(?:a|h[1-6])\b[^>]*(?:id|name)=["\']([^"\']+)',s)); counts={}
 for line in strip_fences(s).splitlines():
  m=re.match(r'^ {0,3}#{1,6}\s+(.+?)\s*#*$',line)
  if not m: continue
  h=m[1].lower(); h=re.sub(r'<[^>]+>','',h); h=h.replace('`','')
  h=''.join(c for c in h if c in '-_ ' or unicodedata.category(c)[0] in 'LN M'.replace(' ',''))
  h=h.replace(' ','-'); n=counts.get(h,0); counts[h]=n+1; ids.add(h+(f'-{n}' if n else ''))
 return ids
def destinations(s):
 s=strip_fences(s); s=re.sub(r'(`+).*?\1', '', s); refs={m[1].casefold():m[2] for m in re.finditer(r'^\s{0,3}\[([^\]]+)\]:\s*<?([^\s>]+)>?',s,re.M)}
 for m in re.finditer(r'!?\[[^\]\n]*\]\(',s):
  start=m.end(); depth=1; i=start
  while i<len(s) and depth:
   if s[i]=='(' and (i==0 or s[i-1]!='\\'): depth+=1
   if s[i]==')' and (i==0 or s[i-1]!='\\'): depth-=1
   i+=1
  if depth: errors.append('unclosed inline link: '+s[m.start():m.start()+80]); continue
  target=s[start:i-1].strip()
  target=target[1:target.find('>')] if target.startswith('<') else re.split(r'\s+["\']',target)[0]
  yield target
 for m in re.finditer(r'!?\[([^\]\n]+)\]\[([^\]\n]*)\]',s):
  key=(m[2] or m[1]).casefold()
  require(key in refs,'undefined reference '+key)
  if key in refs: yield refs[key]
 for target in refs.values(): yield target
md=[p for p in paths if p.suffix=='.md']; cache={p.resolve():anchors(p.read_text()) for p in md}; links=[]; external=[]; blocks=[]
for p in md:
 s=p.read_text()
 for target in destinations(s):
  u=urllib.parse.urlsplit(target)
  if u.scheme or target.startswith('//'): external.append(target); continue
  dest=(p.parent/urllib.parse.unquote(u.path)).resolve() if u.path else p.resolve()
  require(dest.exists(),f'{p}: missing {target}')
  if u.fragment and dest.exists() and dest.suffix=='.md': require(urllib.parse.unquote(u.fragment) in cache.get(dest,set()),f'{p}: missing anchor {target}')
  links.append((str(p),target))
 for m in re.finditer(r'^```json\s*\n(.*?)^```\s*$',s,re.M|re.S):
  try: parse_json(m[1])
  except Exception as e: errors.append(f'{p}: JSON example: {e}')
  blocks.append(str(p))
for p in paths:
 if p.suffix=='.json':
  try: parse_json(p.read_text())
  except Exception as e: errors.append(f'{p}: JSON file: {e}')
pumls=[p for p in paths if p.suffix=='.puml']; svgs=[p for p in paths if p.suffix=='.svg']
for p in pumls: require(p.parts[0]=='diagrams' and p.with_suffix('.svg') in paths,f'{p}: diagram location/pair')
for p in svgs:
 require(p.with_suffix('.puml') in paths,f'{p}: missing source')
 try:
  r=ET.parse(p).getroot(); require(r.tag.endswith('svg'),str(p)+': root'); require('width' in r.attrib and 'height' in r.attrib,str(p)+': dimensions'); require('Syntax Error' not in p.read_text(),str(p)+': renderer error')
 except Exception as e: errors.append(f'{p}: SVG: {e}')
old=json.loads(Path('docs/apiary/accepted-inputs.json').read_text()); current=json.loads(Path('docs/apiary/current-inputs.json').read_text())
require(len(old['entries'])==len(current['entries'])==16,'input count')
for e,c in zip(old['entries'],current['entries']):
 b=Path(e['logical_path']).read_bytes(); h=hashlib.sha256(b).hexdigest(); require(c['logical_path']==e['logical_path'] and c['sha256']==h and c['size_bytes']==len(b), 'current input mismatch '+e['logical_path'])
 if h!=e['sha256']:
  frozen=subprocess.check_output(['git','show',e['candidate_tree']+':'+e['logical_path']]); require(e['logical_path']=='.research/260908_claude-lineage.md' and frozen==b+b'\n','unexpected original mismatch')
for p in paths:
 if p.is_file(): inventory.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
# Source catalogs: verify recorded range bounds and GitHub blob locator syntax without network calls.
source_links=set()
for p in paths:
 if p.suffix=='.json' and p.parts[0]=='.research':
  def walk(v):
   if isinstance(v,str):
    if 'github.com/' in v and '/blob/' in v: source_links.add(v)
   elif isinstance(v,list):
    for x in v: walk(x)
   elif isinstance(v,dict):
    for x in v.values(): walk(x)
  walk(json.loads(p.read_text()))
floating_sources=[]
for url in source_links:
 if not re.search(r'/blob/[0-9a-f]{40}/.+',url): floating_sources.append(url)
 for a,b in re.findall(r'#L(\d+)-L(\d+)',url): require(int(a)<=int(b),'reversed source range: '+url)
text=Path('docs/apiary/migration-conformance.md').read_text(); table=re.search(r'\| V01.*?\| V21[^\n]*',text,re.S)
require(table is not None and '\n\n' not in table[0],'V01-V21 disconnected table')
# Small falsifiers for the checker itself; these do not test runtime behavior.
require('тест-anchor' in anchors('# Тест anchor'),'anchor control')
require('missing.md#absent' in list(destinations('[x](missing.md#absent)')),'link control')
try: parse_json('{"x":1,"x":2}'); errors.append('duplicate-key control admitted')
except ValueError: pass
stats={'markdown_files':len(md),'local_links':len(links),'json_files':sum(p.suffix=='.json' for p in paths),'json_examples':len(blocks),'diagram_pairs':len(pumls),'svg_files':len(svgs),'catalog_pinned_blob_urls':len(source_links)-len(floating_sources),'catalog_floating_document_urls':floating_sources,'external_links_not_refetched':len(external),'current_input_hashes':16,'original_matching_hashes':15,'runtime_probes':0,'errors':errors}
(scratch/'validation.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n'); (scratch/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n'); (scratch/'local-links.json').write_text(json.dumps(links,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(stats,ensure_ascii=False,indent=2)); sys.exit(bool(errors))
