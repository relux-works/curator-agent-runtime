from pathlib import Path
import hashlib,json,re
r=Path('.temp/TASK-260908-1v88g1/rev2')
h=json.loads((r/'diagram-sha256.json').read_text())
assert len(h)==4
for name,digest in h.items():
 assert hashlib.sha256((Path('diagrams/research/codex-pi')/name).read_bytes()).hexdigest()==digest
assert not Path('.research/260908_codex-pi-diagrams').exists()
s=Path('.research/260908_codex-pi.md').read_text()
links=re.findall(r'\]\((\.\./diagrams/[^)]+)\)',s);assert len(links)==2
for link in links: assert (Path('.research')/link).is_file()
new=s[s.index('**Оговорка F1'):s.index('**Вывод.** Coercion')]
anchors=re.findall(r'https://github.com/earendil-works/pi/blob/b2602be77cb7b0de45dd616407fd210daa48aa75/([^#)]+)#L(\d+)',new)
assert len(anchors)==7
for file,line in anchors:
 lines=(Path('.temp/TASK-260908-1v88g1/pi-mono')/file).read_text().splitlines()
 assert 0<int(line)<=len(lines)
for file in [Path('.research/260908_codex-pi.md'),*Path('diagrams/research/codex-pi').glob('*.puml')]:
 assert all(line.rstrip()==line for line in file.read_text().splitlines()),file
print('PASS: 4/4 diagram hashes unchanged; old directory absent; 2/2 relocated links; 7/7 F1 pinned anchors resolve; 3/3 text deliverables without trailing whitespace.')
print('Bound: artifact integrity/existence only; no upstream execution, provider admission proof or runtime security test.')
