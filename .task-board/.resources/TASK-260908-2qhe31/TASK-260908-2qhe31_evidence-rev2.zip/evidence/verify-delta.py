from pathlib import Path
import hashlib,json,re,difflib
root=Path.cwd(); scratch=root/'.temp/rework-rev2'
paths=[Path('.spec/apiary-runtime-design.md'),*sorted(Path('docs/apiary').glob('*')),*sorted(Path('diagrams/apiary').glob('*'))]
changed=[];unchanged=[];diff=[];errors=[];anchors=0
for p in paths:
 if not p.is_file(): continue
 before=scratch/('design-before.md' if str(p).startswith('.spec/') else ('docs-before' if str(p).startswith('docs/') else 'diagrams-before'))
 if not str(p).startswith('.spec/'):before=before/p.name
 if p.read_bytes()!=before.read_bytes():
  changed.append(str(p))
  if p.suffix in ['.md','.puml']:diff.extend(difflib.unified_diff(before.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='rev1/'+str(p),tofile='rev2/'+str(p)))
 else:unchanged.append(str(p))
 if p.suffix=='.md':
  for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   if target.startswith('http') or '#' not in target:continue
   target,anchor=target.split('#',1); dest=p.parent/target
   if not dest.exists():continue
   hs=[re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-') for h in re.findall(r'^#+ (.+)$',dest.read_text(),re.M)]
   if anchor not in hs:errors.append(f'anchor {p} {target}#{anchor}')
   anchors+=1
assert len(paths)==28
for p in paths:
 if p.suffix=='.md':
  for block in re.findall(r'```json\n(.*?)\n```',p.read_text(),re.S):
   obj=json.loads(block)
   def walk(x):
    if isinstance(x,dict):
     if 'object_format' in x:
      assert x['object_format'] in ('sha1','sha256')
      assert re.fullmatch('[0-9a-f]{'+str(40 if x['object_format']=='sha1' else 64)+'}',x['oid'])
     for v in x.values():walk(v)
    elif isinstance(x,list):
     for v in x:walk(v)
   walk(obj)
(scratch/'revision-2.diff').write_text(''.join(diff))
(scratch/'delta-validation.json').write_text(json.dumps({'changed':changed,'unchanged':unchanged,'own_anchors_checked':anchors,'errors':errors,'scope':'Compared against preserved revision-1 authored files; no runtime behavior tested'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'changed':changed,'unchanged_count':len(unchanged),'own_anchors_checked':anchors,'errors':errors},ensure_ascii=False,indent=2))
assert not errors
