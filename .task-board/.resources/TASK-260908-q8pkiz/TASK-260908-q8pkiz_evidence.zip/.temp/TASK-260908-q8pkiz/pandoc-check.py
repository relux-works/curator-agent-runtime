from pathlib import Path
import subprocess,json,urllib.parse,sys
from html.parser import HTMLParser
class AnchorParser(HTMLParser):
 def __init__(self): super().__init__(); self.ids=set()
 def handle_starttag(self,tag,attrs):
  for key,value in attrs:
   if key in ("id","name") and value: self.ids.add(value)
root=Path.cwd(); out=root/'.temp/TASK-260908-q8pkiz'; paths=[Path(p) for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines() if p.endswith('.md') and not p.startswith(('.task-board/','.temp/'))]
headers={}; links=[]; commands=[]; errors=[]; tables=[]
def walk(v,visit):
 if isinstance(v,dict):
  visit(v)
  for x in v.values(): walk(x,visit)
 elif isinstance(v,list):
  for x in v: walk(x,visit)
for p in paths:
 cmd=['pandoc','-f','gfm','-t','json',str(p)]; r=subprocess.run(cmd,capture_output=True,text=True); commands.append({'command':cmd,'exit':r.returncode,'stderr':r.stderr});
 if r.returncode: errors.append(str(p)+': parse failed'); continue
 doc=json.loads(r.stdout); ids=set()
 def visit(n):
  if n.get('t')=='Header': ids.add(n['c'][1][0])
  if n.get('t') in ['Link','Image']: links.append((p,n['c'][-1][0]))
  if n.get('t')=='Table' and p==Path('docs/apiary/migration-conformance.md'): tables.append(n)
 walk(doc,visit); html=AnchorParser(); html.feed(p.read_text()); ids.update(html.ids); headers[p.resolve()]=ids
for p,target in links:
 u=urllib.parse.urlsplit(target)
 if u.scheme or target.startswith('//'): continue
 d=(p.parent/urllib.parse.unquote(u.path)).resolve() if u.path else p.resolve()
 if not d.exists(): errors.append(f'{p}: missing {target}')
 if u.fragment and d.suffix=='.md' and d.exists() and urllib.parse.unquote(u.fragment) not in headers[d]: errors.append(f'{p}: missing anchor {target}')
vt=[t for t in tables if 'V01' in json.dumps(t)]; count=sum(1 for i in range(1,22) if f'V{i:02d}' in json.dumps(vt[0])) if vt else 0
if count!=21: errors.append('V01-V21 not in one rendered table')
local=sum(not urllib.parse.urlsplit(t).scheme and not t.startswith('//') for _,t in links)
result={'markdown_files':len(paths),'parsed':len(headers),'rendered_links_images':len(links),'local_links_images':local,'negative_table_rows':count,'errors':errors,'commands':commands}
(out/'pandoc-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='commands'},ensure_ascii=False,indent=2)); sys.exit(bool(errors))
