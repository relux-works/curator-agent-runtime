import subprocess, pathlib, json, re, urllib.parse
root=pathlib.Path.cwd()
out=root/'.temp/review-q8pkiz-rev2'
def git(*args): return subprocess.check_output(['git',*args])
old='bdbeeea1474b0c37160338a86d7fbe287e4ee6ee'
new='6f1df833192dfb25a1c0da5dcaca230a6817dfb2'
changed=git('diff','--name-only',old,new).decode().splitlines()
assert changed==['README.md'], changed
files=[x for x in git('ls-tree','-r','--name-only',new).decode().splitlines() if not x.startswith('.task-board/')]
for p in files:
    assert (root/p).read_bytes()==git('show',new+':'+p),p
prior=git('show',old+':README.md').decode().splitlines()
current=(root/'README.md').read_text().splitlines()
assert len(prior)==len(current)
assert [i+1 for i,(a,b) in enumerate(zip(prior,current)) if a!=b]==[38]
assert 'ещё проходит' not in current[37]
assert 'TASK-260908-q8pkiz' in current[37]
assert '[Открытые вопросы](UNRESOLVED_QUESTIONS.md)' in current[37]
assert 'Выбранные Go/kernel/central/MCP/XMPP/L0 решения повторного выбора не требуют.' in current[37]
ast=json.loads(subprocess.check_output(['pandoc','-f','gfm','-t','json','README.md']))
links=[]
def walk(o):
    if isinstance(o,dict):
        if o.get('t') in ('Link','Image'): links.append(o['c'][-1][0])
        for v in o.values(): walk(v)
    elif isinstance(o,list):
        for v in o: walk(v)
walk(ast)
local=[]
for link in links:
    u=urllib.parse.urlsplit(link)
    if u.scheme or u.netloc: continue
    p=root/urllib.parse.unquote(u.path or 'README.md')
    assert p.exists(),link
    if u.fragment:
        html=subprocess.check_output(['pandoc','-f','gfm','-t','html',str(p)]).decode()
        assert 'id="'+urllib.parse.unquote(u.fragment)+'"' in html,link
    local.append(link)
report={'candidate':new,'delta_from_rev1':changed,'live_candidate_files_equal':len(files),'unchanged_nonboard_files_vs_rev1':len(files)-1,'changed_lines':[38],'readme_local_links_checked':len(local),'links':local}
(out/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
commands=json.loads((root/'task-board.config.json').read_text())['spawn']['worktree_isolation']['validation']['commands']
results=[]
for i,cmd in enumerate(commands,1):
    r=subprocess.run(cmd,shell=True,executable='/bin/zsh',capture_output=True)
    (out/f'gate-{i:02}.log').write_bytes(r.stdout+r.stderr)
    results.append({'command':cmd,'exit_code':r.returncode})
(out/'gates.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
assert len(results)==3 and all(r['exit_code']==0 for r in results)
