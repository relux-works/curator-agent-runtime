from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET,subprocess
root=Path.cwd()
manifest=json.loads(Path('.temp/architecture/input-verification.json').read_text())
logical={e['logical_path']:e for e in manifest['entries']}
files=[Path('.spec/apiary-runtime-design.md'),*Path('docs/apiary').glob('*.md'),Path('diagrams/apiary/README.md')]
errors=[]; own=[]; pending=[]; blocks=[]; diagrams=[]; upstream=[]
for e in manifest['entries']:
 b=Path(e['local_path']).read_bytes()
 if hashlib.sha256(b).hexdigest()!=e['sha256']: errors.append('input hash '+e['logical_path'])
for p in files:
 s=p.read_text()
 if not s.endswith('\n') or s.endswith('\n\n'): errors.append('EOF '+str(p))
 for i,l in enumerate(s.splitlines(),1):
  if l.rstrip()!=l: errors.append(f'whitespace {p}:{i}')
 for i,m in enumerate(re.finditer(r'```json\n(.*?)\n```',s,re.S),1):
  try:
   obj=json.loads(m.group(1)); blocks.append({'file':str(p),'index':i,'status':'parsed'})
   # Proposed examples: format checks only, no claim of normative conformance.
   for digest in re.findall(r'sha256:([^"\s]+)',m.group(1)):
    if not re.fullmatch('[0-9a-f]{64}',digest): errors.append('digest format '+str(p))
  except Exception as ex: errors.append(f'JSON {p}:{i}: {ex}')
 for target in re.findall(r'\]\(([^)]+)\)',s):
  if target.startswith(('http:','https:')):
   upstream.append(target);continue
  target=target.split('#')[0]
  if not target:continue
  resolved=(p.parent/target).resolve()
  try: rel=str(resolved.relative_to(root))
  except ValueError: errors.append('outside root link '+str(p)+' '+target);continue
  if resolved.exists(): own.append({'source':str(p),'target':rel})
  elif rel in logical:pending.append({'source':str(p),'target':rel,'sha256':logical[rel]['sha256']})
  else:errors.append('missing link '+str(p)+' '+target)
for p in sorted(Path('diagrams/apiary').glob('*.svg')):
 try:
  s=p.read_text(); el=ET.fromstring(s)
  if 'Syntax Error' in s or 'An error has occured' in s:errors.append('render error '+str(p))
  dims={k:el.attrib.get(k) for k in ['width','height','viewBox']}
  diagrams.append({'file':str(p),'dimensions':dims,'source_exists':p.with_suffix('.puml').exists()})
 except Exception as ex:errors.append('SVG '+str(p)+str(ex))
public=json.loads(Path('docs/apiary/accepted-inputs.json').read_text())
if public['entries']!=[{k:v for k,v in e.items() if k!='local_path'} for e in manifest['entries']]: errors.append('mapping mismatch')
tracked=subprocess.run(['git','diff','--name-only','HEAD'],text=True,capture_output=True,check=True).stdout.splitlines()
if tracked:errors.append('unexpected tracked changes '+str(tracked))
# Current task started clean; only these new authored roots are allowed.
status=subprocess.run(['git','status','--porcelain','--untracked-files=all'],text=True,capture_output=True,check=True).stdout.splitlines()
for row in status:
 p=row[3:]
 if not (p.startswith('.spec/') or p.startswith('docs/apiary/') or p.startswith('diagrams/apiary/')):errors.append('scope '+row)
if len(diagrams)!=9:errors.append('diagram count')
report={'input_digests':{'verified':len(manifest['entries']),'required':16},'documents':len(files),'own_links':len(own),'pending_research_links':len(pending),'pending_mappings':pending,'json_examples':blocks,'diagrams':diagrams,'external_urls_count':len(set(upstream)),'external_network_revalidation':'not run; frozen research input authority','scope_status':status,'errors':errors,'limits':['JSON parsing/digest shape is not runtime or crypto conformance','SVG XML checks require accompanying visual inspection','Research links intentionally resolve through frozen manifest; combined-tree validation belongs to consolidation','No runtime tests or benchmarks performed']}
Path('.temp/architecture/validation-01.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['pending_mappings','scope_status','diagrams']},ensure_ascii=False,indent=2))
raise SystemExit(bool(errors))
