# Исполнение, восстановление и точная интеграция

Статус: proposed contracts. [Wire и authority](authority-wire.md), [central interface](tool-skills.md).

## Admission и WAL исполнителя

Executor — authoritative owner физического sandbox и operation WAL. Broker держит correlation, но локальная память worker не решает, произошёл ли effect. Key операции `(project,grant,operation_id)` резервируется вместе с body digest, authority permit, assignment, sandbox generation, budget и owner **до dispatch** в одной durable transaction. Только после commit возвращается `admitted`. При одинаковом duplicate возвращается stored state; при другом body — conflict. Downstream idempotency key сохраняется при reconnection, renewal и ownership transfer.

Lifecycle закрыт: `reserved → dispatching → running → succeeded | failed | cancelled | outcome_unknown`; `refused` возможен до reservation. `cancel_requested` — отдельный durable flag, не terminal state. `dispatching` записывается до передачи в process supervisor/sink. Recovery видит `reserved` без dispatch marker — может продолжить только после fresh authority check. Recovery видит dispatch marker без доказанного outcome — сначала observe/reconcile, не execute again. Terminal outcome immutable; поздний reconciliation уточняет unknown отдельной causally-linked записью, не переписывает прошлое.

| Сбой | Источник истины | Разрешённое действие |
|---|---|---|
| До durable reserve | Authoritative lookup, не клиентский timeout | Повтор exact intent; если read unavailable — ждать, не считать отсутствующим |
| После reserve, до dispatch marker | WAL owner | Fresh permit и продолжение той же операции |
| После marker, до/после реального effect, до receipt | Supervisor/sink query | `outcome_unknown`; no blind retry, budget retained |
| Receipt synced, reply потерян | Executor WAL | Повторная выдача того же receipt |
| Worker умер, executor жив | Executor и assignment authority | Новый worker получает observations; не сбрасывает budget/operation ID |
| Executor недоступен, lease истёк | Authority + sink fencing proof | Нет доказанного rollback; неизвестную mutation нельзя перенести и повторить |
| Corrupt WAL middle | Storage verifier | Quarantine, stop dispatch; не «пустая база» |

`failed` означает наблюдаемый неуспешный exit/result, но не отсутствие частичных effects. `cancelled` означает подтверждённую остановку процесса, не rollback. `succeeded` означает success конкретной команды, не корректность кода/задачи. Receipt имеет отдельные `exit_code`, `effect_state` (`none`, `partial`, `applied`, `unknown`) и termination observation. Для произвольного shell точный перечень effects может быть unknown; нельзя заменить observation выдуманной полнотой.

Для внешних non-idempotent действий worker grant по умолчанию network-none, без credentials и publication. Именованный runner operation может иметь sink-specific idempotency/fencing contract. Если такого механизма нет, crash after dispatch требует reconciliation или human-owned resolution, не retry с новым operation ID. Даже idempotent endpoint требует достаточного срока dedup retention. Сериализующий gateway без поддержки downstream не устраняет crash gap между external effect и собственной записью.

![Recovery/cancel](../../diagrams/apiary/operation-recovery.svg)

## Команды, cwd/env и long-running processes

`exec.argv` запускается без implicit login shell. Для shell пользовательская команда должна явно включить `/bin/sh`, `-c`, текст. Нет `source ~/.zshrc`, user HOME, inherited PATH или глобального `chdir`. `cwd` — относительный mount alias path внутри generation. `env` — per-call overlay разрешённых имён поверх pinned base environment; PATH/toolchain/home/tmp задаёт sandbox image. Env names для dynamic loader, credentials, agent sockets и control endpoints не допускаются worker policy. Shell `cd`, `export`, aliases и функции живут только в данном process; следующая команда снова получает explicit cwd/env.

Filesystem сохраняется между командами данной generation, shell memory — нет. Один multi-step script может связать `cd`, build и test внутри одного exec. Модель не должна ожидать persistence произвольного интерактивного shell. Это осознанное уточнение local-like shell из [Apiary paper](https://github.com/relux-works/apiary-docs/blob/b1ad6d76d803cd3f8e46e2b9621d266d36f3a0c7/paper/paper.tex); процессная сохранность требует механизма, а не метафоры.

Supervisor возвращает opaque process handle, связанный с authenticated principal, assignment, operation и sandbox generation. PID остаётся private implementation detail; после restart reuse PID не даёт старому handle полномочий. Baseline stdin закрыт; interactive PTY и произвольный stdin write отложены. Допустим long-running build/server в пределах явно заданного grant/deadline; пока он жив, workspace-exclusive slot занят. Если нужен server и tests одновременно, отдельный scoped read/test concurrency profile должен быть разрешён заранее, не вытекать из shell background `&`.

`poll` — новый model call ID и read-only query к прежнему process/operation; cursor monotonically increasing byte offset + stream ID. Output chunks ≤64 KiB, model view ≤32 KiB/call, stdout/stderr различаются; spool quota 16 MiB/process, overflow останавливает producer согласно pinned policy и сохраняет truncation/digest. Потерянный cursor возвращает `cursor_expired` + available range/artifact ref, не молча начинает с нуля. `cancel` требует владельца handle, записывает request, сигнализирует process group (TERM, затем KILL после 2 s) и ждёт supervisor observation; children должны оставаться в sandbox cgroup/job. Если platform не подтверждает containment descendants, assurance partial.

Cancel racing exit: один supervisor serializes exit и cancel request; terminal exit не заменяется cancellation success. Restart sandbox увеличивает generation: все handles `session_lost`, process state не восстановлен. Files могут быть восстановлены из snapshot как **новая** generation; old receipts остаются historical. Нельзя обещать миграцию памяти процесса, открытых файлов, TCP streams и shell jobs без checkpoint/restore backend — такого backend в baseline нет.

Дополнительные process errors закрыты: `process_not_found`, `process_forbidden`, `cursor_expired`, `output_limit`, `timeout`, `session_lost`, `executor_unavailable`. Они дополняют admission errors; transport availability не определяет effect outcome.

## Sandbox и platform assurance

Executor создаёт disposable per-assignment workspace с pinned base commit/image; main refs и project secrets не mounted. Linux baseline: отдельные user/mount/PID/network namespaces, no-new-privileges, seccomp policy, cgroups CPU/RAM/PIDs, read-only toolchain, writable task root/tmp, denied egress, no host sockets/device nodes. Конкретный backend должен доказать это production probes, а не заявить по наличию container. Недоверенный code может exploit kernel; для hostile multi-tenant code профиль требует VM/microVM boundary и отдельную qualification. Root на host остаётся TCB.

Snapshot/candidate builder использует immutable commit tree, проверяет scope по фактическим diff paths и запрещает protected path edits. Lexical scope intent не достаточен против symlink/hardlink/mount tricks: supervisor ограничивает actual FS. Shell может прочитать весь granted repo, это допустимый containing set, не точный effect trace. Перед выдачей remote task policy определяет data classes, которые contributor/model sink увидят через stdout. Network-none у sandbox не означает, что repo data не уйдёт в model provider: этот sink отдельно admitted.

macOS/iOS: именованные runner jobs (`xcodebuild-test`, `codesign-candidate`, `device-test`) на закреплённой macOS host/toolchain/device identity; модель не получает keychain или unlimited host shell. Physical device state/permissions/session preservation — часть job contract; destructive reset только explicit authorized operation. Apple toolchain, signing service, simulator/device и их операторы — дополнительные TCB и partial isolation classes, не Linux VM по аналогии. Android device job аналогично не uninstall/clear/force-stop ради baseline. Task requiring full isolation для unavailable device capability получает отказ, не fallback.

Каждый environment receipt перечисляет capability classes: filesystem, processes/signals, egress, CPU/RAM/PIDs/disk, devices, credentials, protected publication. Для каждого `full/partial/none`, backend/revision, доказательство и ограничение. Package build assurance Curator и runtime execution assurance не одно поле. [curator-spec assurance](https://github.com/relux-works/curator-spec/blob/87a0d0060bad64ab883d007dcdf35df7485368bf/protocol/assurance.md#L19).

## От задачи до main

Task lifecycle: `proposed → contracted → assigned → executing → submitted → candidate_frozen → reviewing → accepted → integrated`; альтернативы `rejected`, `cancelled`, `blocked`. Названия — proposal state vocabulary, не текущие task-board statuses. Scope reservation живёт до integrated/cancelled, execution slot можно освободить после snapshot. Изменение contract после submission создаёт revision и инвалидирует прежнюю acceptance.

1. Authority фиксирует TaskContract с scope/AC/budget/environment/reviewer policy и revision. Worker получает assigned sandbox от executor, не writable main.
2. Executor останавливает mutations и делает immutable revision snapshot R. Worker Submission подписывает claim `(task, contract, assignment, plan, R, snapshot receipt)`; summary не источник tree.
3. Authority фиксирует eligible reviewer set и policy **до** построения I. Runner строит конкретный integration commit I на target M, сохраняет tree/object availability и recipe. После I commit выбирается randomness/детерминированная selection по уже frozen eligible set. В L0 seed выдаёт доверенная authority после I; это не publicly unbiased randomness. Для adversarial profile нужен проверенный внешний beacon/commit-reveal contract.
4. Независимый `check-initiator` из frozen eligible policy запрашивает test run; его identity отдельно от producer и reviewer, а runner — execution service. Третья роль сама по себе не доказывает независимую машину: environment verifier отдельно устанавливает host/toolchain identity и требуемые independence predicates. При отсутствии требуемого участника задача ждёт/отказывается по policy, self-review fallback запрещён. Review/test environment получает exact I read-only или отдельную disposable copy. Reviewer не может менять I во время оценки. Tests тоже не превращают свою mutable worktree в candidate: исходный I сохраняется, изменения тестовой среды изолированы.
5. Required verdicts/attestations привязываются к tuple `(project,task,contract_digest,policy_digest,M,R,I,tree,environment_digest,test_recipe_digest)`. Reviewer independence проверяется по owner enrollment, role separation и policy; declared model family может быть self-report, это явно отмечается.
6. Authority acceptance validator проверяет complete required evidence set, issuer roles, freshness, signatures, exact tuple и refusal outcomes. Arbitrary judgement остаётся в ReviewAttestation. Missing/unreadable/unknown evidence не success. Conformance coverage reports numerator/denominator требуемых checks; это не code coverage.
7. Publication runner непосредственно перед landing проверяет actual remote main=M, candidate head=I, signed commits/allowed author policy и current acceptance. Выполняет non-rewriting CAS M→I. Если target изменился, создаёт новый I′ на M′, новое review/tests; path-disjointness не переносит approval.
8. CAS success + durable IntegrationReceipt завершает transition. Сбой после push до receipt требует read remote exact ref/reflog/server receipt, не повтор merge с новым candidate. Если remote чтение недоступно, `outcome_unknown`; если ref теперь другой, нужна доказуемая история, не догадка по ancestor alone.

![Task/candidate](../../diagrams/apiary/task-integration.svg)

Proposed evidence fragment (не криптографически валидный fixture):

```json
{
  "record_type": "TestAttestation",
  "candidate_id": "candidate-12",
  "contract_revision": 2,
  "base_commit": "1111111111111111111111111111111111111111",
  "integration_commit": "2222222222222222222222222222222222222222",
  "environment_digest": "sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
  "test_recipe_digest": "sha256:eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
  "checks": {"required": 7, "observed": 7, "passed": 7, "unknown": 0},
  "outcome": "passed"
}
```

Числа 7/7 — пример формата, не выполненные здесь tests. Production acceptance содержит идентичности семи checks и их output refs; одних counters недостаточно. Test code, который проверялся helper-only, не доказывает production gate. Project signing key держит runner signer, подписывающий только approved exact commit objects с configured human/project identity, не worker.

## Coding walkthrough

Задача: исправить parser, который принимает отрицательный timeout, и добавить regression test. Contract r2 разрешает `internal/parser/**`, baseline M, Go toolchain/image digest, network-none, 200 exec requests/30 min allocation; readonly остальной repo, protected config/main/signing недоступны. Нужны test negative timeout, valid zero/positive и review независимого owner. Worker profile — direct admitted ModelPort, remote WorkspaceRef `sb-17/g3`, один central.

Worker получает immutable task/context bundle. `central.exec` с `argv=["rg","timeout","internal/parser"]`, `cwd="repo"`, `env={}` создаёт call-1/op-1; broker связывает grant, executor получает permit, reserve/sync/start/receipt. Модель видит bounded output с source/digest. Следующий exec явно запускает shell script, который применяет ограниченный patch в parser/tests; unknown shell effects ограничены task mount policy. Попытка изменить `.github` denied платформой и snapshot scope check независимо от текста команды.

`central.exec go test ./internal/parser` создаёт call-3/op-3. Если команда дольше 2 s, ответ running+handle h3; call-4 `poll h3` не повторяет op-3. Следующий test run — новый operation, поскольку это новое намерение. Модель сравнивает exit/output и при необходимости исправляет код в прежней generation. Terminal answer содержит brief result; host submission flow, а не текст «готово», запрашивает freeze R. Runner строит I, другой reviewer проверяет exact diff и negative tests, authority принимает evidence, runner CAS. Worker не имел ни checkout локально, ни git push key, ни authority signing.

## Failure walkthroughs

**Stream truncation.** Модель прислала завершённый JSON `exec`, затем terminal `length`. Broker сохраняет interrupted attempt, не допускает op, effect count zero. Новый inference attempt видит interruption; ID старого partial call не исполнен.

**Потерянный ответ после build.** op-3 succeeded в executor WAL, XMPP response потерян. Worker повторяет observation через новый transport message; exact operation lookup возвращает прежний receipt. Build не запускается повторно. Если WAL read failed — status unknown, не not-found fallback.

**Публикация с неопределённым исходом.** Runner послал CAS, соединение оборвалось. Operation остаётся outcome_unknown и удерживает reservation; новый orchestrator term не mint новый publish. Reconcile actual target/ref receipt устанавливает success либо definite refusal. При недоступном remote задача blocked на эту интеграцию; остальные disjoint задачи могут продолжаться.

**Failover во время shell.** Authority term 15 заменяет 14, stop запрещает новые permits. Старый orchestrator renewal denied. Уже начатый process h3 останавливается supervisor или достигает timeout; его late receipt остаётся epoch-6/g3 historical. Перенос worker не перемещает h3; sandbox restart создаёт g4 и session_lost. Новая generation не выдаётся за возобновлённую shell memory.

**Target advanced во время review.** Reviewer принял I на M, main уже M′. CAS refusal инвалидирует landing attempt. Runner создаёт I′; даже unchanged patch и непересекающиеся пути требуют нового exact-candidate evidence. Старый verdict доступен как reference, не accepted evidence I′.
